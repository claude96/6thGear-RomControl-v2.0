#!/system/bin/sh

cd /storage/emulated/0
echo "working from assets" >> test-assets.txt